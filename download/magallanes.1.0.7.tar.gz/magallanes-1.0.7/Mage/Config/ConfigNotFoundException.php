<?php

namespace Mage\Config;

use Mage\Yaml\Exception\RuntimeException;

/**
 *
 * @author Vladimir Grigor <vgrigor@gmail.com>
 */
class ConfigNotFoundException extends RuntimeException
{
}
